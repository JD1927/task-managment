export const duplicateUsernameCode = '23505';
