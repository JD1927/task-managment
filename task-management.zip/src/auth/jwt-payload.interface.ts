export interface JwtPayload {
  username: string;
  name: string;
  birthDate: string;
}
